ezChromato v1 - Arduino Uno shield for the ADS1220 module (CJMCU-1220)

Files (RS-274X Gerber, millimetres):
  ezChromato_v1.GTL  top copper
  ezChromato_v1.GBL  bottom copper (ground plane)
  ezChromato_v1.GTS  top solder mask
  ezChromato_v1.GBS  bottom solder mask
  ezChromato_v1.GTO  top silkscreen
  ezChromato_v1.GKO  board outline
  ezChromato_v1.DRL  Excellon drill file (all holes plated)

Ordering parameters:
  2 layers, 68.58 x 53.34 mm, 1.6 mm thick, 1 oz copper
  min track 0.4 mm, min clearance 0.4 mm, drills 0.9 / 1.0 / 1.3 mm (60 holes)
  HASL (or ENIG) finish, any colour

ADS1220 module: 2 x 8 pins, 2.54 mm pitch, 20.32 mm (0.8") between rows

Wiring:
  DRDY->D2  MISO->D12  MOSI->D11  SCLK->D13  CS->D7
  DVDD+AVDD->5V  DGND+AGND+CLK->GND
  IN+ -> R1 10k -> AIN0, C2 100n between IN+ and GND (across the input)
  START->D4  READY->D5 (C1 100n to GND)
